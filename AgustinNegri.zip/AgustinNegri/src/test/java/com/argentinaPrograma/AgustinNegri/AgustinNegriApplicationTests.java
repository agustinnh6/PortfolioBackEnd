package com.argentinaPrograma.AgustinNegri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgustinNegriApplicationTests {

	@Test
	void contextLoads() {
	}

}
